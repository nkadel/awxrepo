Release history
===============

.. currentmodule:: sniffio

.. towncrier release notes start

Sniffio 1.1.0 (2019-04-19)
--------------------------

Features
~~~~~~~~

- Sniff for curio. (`#5 <https://github.com/python-trio/sniffio/issues/5>`__)


sniffio 1.0.0 (2018-07-31)
--------------------------

Initial release.
